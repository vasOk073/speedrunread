def parser(filename: str):
    file = open(filename,encoding="utf-8", mode="r+")
    slovar = list(file.readlines())
    file.close()
    itog = list()
    for line in slovar:
        itog.append(line.split())
    return itog

