import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QFileDialog
from PySide6.QtCore import QCoreApplication
from PySide6.QtCore import QTimer, QEventLoop
from ui.window import Ui_MainWindow
from modules.textparser import parser
from time import sleep, time

def delay(msec):
    loop = QEventLoop()
    QTimer().singleShot(msec, lambda: loop.quit())
    loop.exec()
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.OpenFile.clicked.connect(self.OpenFile)
        self.ui.Start.clicked.connect(self.Start)
        self.ui.Stop.clicked.connect(self.Stop)
        self.stoptrigger = 1
    def OpenFile(self):
        filename = QFileDialog().getOpenFileName()
        self.words = parser(filename[0])
        self.stoptrigger = 0

    def Start(self):
        for line in self.words:
            if self.stoptrigger == 1:
                break
            delay(2000)
            for word in line:
               delay(1000)
               self.ui.label.setText(str(word))

    def Stop(self):
        exit()


if __name__ == '__main__':
    app = QApplication()
    window = MainWindow()
    window.show()
    sys.exit(app.exec())